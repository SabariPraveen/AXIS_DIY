mainApp.controller('bankController', function ($scope, $rootScope, $state, serverService) {
	$rootScope.formData.stageInfo = '5';
	if ($rootScope.getAPI && !$rootScope.formData.threeinone) {
		if (localStorage.getItem('AxNo') != null) {
			$rootScope.formData.eRefNumber = localStorage.getItem('AxNo');
			$rootScope.getDIYStatus();
		} else {
			window.location.href = (serverService.getHome());
		}
	}
	$rootScope.formData.apiLoading = false;
	$rootScope.formData.stageOrder = 4;
	$rootScope.formData.ifscOption = false;
	$rootScope.formData.bankList = [];
	$rootScope.formData.fields.bankID = "1";
	$scope.disableIFSC = true;
	$rootScope.formData.fields.bankName = '';
	setTimeout(function () {
		$(".select").select2();
		$('.customcheckradio').iCheck({
			checkboxClass: 'icheckbox_minimal',
			radioClass: 'iradio_minimal'
		});
	}, 500)
	/* Get Master Data for Bank List */
	var s_url = "DIYGetBankName";

	var tokenParams = {
		'Email': ($rootScope.formData.fields.email !== null && $rootScope.formData.fields.email !== '') ? $rootScope.formData.fields.email : localStorage.getItem('RxEmail'),
		'Mobile': ($rootScope.formData.fields.mobile !== null && $rootScope.formData.fields.mobile !== '') ? $rootScope.formData.fields.mobile : localStorage.getItem('RxMobile'),
		'PanNumber': ($rootScope.formData.fields.panNumber !== null && $rootScope.formData.fields.panNumber !== '') ? $rootScope.formData.fields.panNumber : localStorage.getItem('RxPan'),
		'DOB': ($rootScope.formData.dob !== null && !angular.isUndefined($rootScope.formData.dob) && $rootScope.formData.fields.dob !== '') ? $rootScope.formData.dob : localStorage.getItem('DOB'),
	}
	//serverService.getList(s_url).then(function (response) {
	serverService.getTokenList(s_url, tokenParams).then(function (response) {
		if (response.IsSuccess) {
			$rootScope.formData.bankList = response.BankDetailsList;
			$scope.bankName('');
		
			setTimeout(function () {
			$(".select").select2();
			}, 200);
		}
	})
	$("html, body").animate({
		scrollTop: 0
	}, "slow");

	var Bank_Info_Stage = '';
	$scope.bankName = function (type) {
		if ($rootScope.formData.fields.bankID !== '' && $rootScope.formData.fields.bankID !== null) {
			$('#ifsc_value').val('');
			$scope.disableIFSC = false;
			$scope.bankNameError = false;
			//$rootScope.formData.fields.bankName = $rootScope.formData.bankList.filter((bankdetails) => bankdetails.BankId == $rootScope.formData.fields.bankID)[0].BankName;
			$rootScope.formData.fields.bankName = $rootScope.formData.bankList.filter(function (bankdetails) {
					return (bankdetails.BankId == $rootScope.formData.fields.bankID);
				})[0].BankName;
				//console.log($rootScope.formData.fields.bankName)
			if ($rootScope.formData.fields.bankName != "Axis Bank" && type == 'changed'){
					setTimeout(function(){ $('#myModal').modal({backdrop: 'static',keyboard: false}); }, 500);
					$rootScope.axisSignatureAction = false;
			}else if($rootScope.formData.fields.bankName == "Axis Bank" ){
					$rootScope.axisSignatureAction = true;
			}
		}
	}

	$scope.changeChar = function () {
		if ($rootScope.formData.fields.accNumber) {
			var inputvalue = $rootScope.formData.fields.accNumber;
			$rootScope.formData.fields.accountNumber = inputvalue;

			var i;
			var AcctNotemp = '';
			for (i = 0; i < inputvalue.length; i++) {
				AcctNotemp = AcctNotemp + '.';
			}
			$rootScope.formData.fields.accNumber = '';
			$rootScope.formData.fields.accNumber = AcctNotemp;
		} else {
			$rootScope.formData.fields.accountNumber = '';
		}

	};

	$scope.changeStar = function () {
		$rootScope.formData.fields.accNumber = '';
		$rootScope.formData.fields.accNumber = $rootScope.formData.fields.accountNumber;
	};

	$scope.getBankInfo = function () {
		if (!$rootScope.getAPI) {
			var s_url = "DIYGetBankDetailsByReferenceNumber";
			var sendData = {
				ReferenceNumber: $rootScope.formData.eRefNumber,
				IsDiy: true,
				EncryptToken: $rootScope.EncryptToken
			}
			var tokenParams = {
				'Email': ($rootScope.formData.fields.email !== null && $rootScope.formData.fields.email !== '') ? $rootScope.formData.fields.email : localStorage.getItem('RxEmail'),
				'Mobile': ($rootScope.formData.fields.mobile !== null && $rootScope.formData.fields.mobile !== '') ? $rootScope.formData.fields.mobile : localStorage.getItem('RxMobile'),
				'PanNumber': ($rootScope.formData.fields.panNumber !== null && $rootScope.formData.fields.panNumber !== '') ? $rootScope.formData.fields.panNumber : localStorage.getItem('RxPan'),
				'DOB': ($rootScope.formData.dob !== null && !angular.isUndefined($rootScope.formData.dob) && $rootScope.formData.fields.dob !== '') ? $rootScope.formData.dob : localStorage.getItem('DOB'),
			}

			$rootScope.formData.apiLoading = true;
			//serverService.apiTokenCall(s_url, sendData, tokenParams).success(function (response)
			serverService.apiCall(s_url, sendData).success(function (response) {
				$rootScope.formData.apiLoading = false;
				if(response.EncryptToken){
				$rootScope.EncryptToken = response.EncryptToken;
				localStorage.setItem('AxToken', response.EncryptToken);
			}
			else{
				if($rootScope.formData.tokenValidation){
					$rootScope.clearBrowsingData();
					$('#APIResponse').modal({backdrop: 'static',keyboard: false});
					$rootScope.apiResponseErrorMsg = "Session Timed Out";
				}
			}

					if (response.IsSuccess) {
						/*if(response.BankDetailsList[0].BankName === "AXIS BANK"){
							$rootScope.axisSignatureAction = true;
							if(response.BankDetailsList[0].AxisSignature === "1"){
							$scope.axisSignature = true;
							}else if(response.BankDetailsList[0].AxisSignature === "0"){
							$scope.axisSignature = false;	
							}
						}else if(response.BankDetailsList[0].BankName !== "AXIS BANK"){
							$rootScope.axisSignatureAction = false;
						}*/
						$scope.formData.fields.accNumber = response.BankDetailsList[0].AccountNumber;
						if(response.BankDetailsList[0].AxisSignature === "1"){
							$scope.axisSignature = true;
						}else if(response.BankDetailsList[0].AxisSignature === "0"){
							$scope.axisSignature = false;
						}
						if ($rootScope.formData.threeinone && $scope.formData.fields.accNumber) {
							$scope.accNumberFreeze = true;
						} else {
							$scope.accNumberFreeze = false;
						}
						$rootScope.formData.fields.accountNumber = $rootScope.formData.fields.accNumber;
						$scope.formData.fields.raccNumber = response.BankDetailsList[0].AccountNumber;
						if ($rootScope.formData.threeinone && $scope.formData.fields.raccNumber) {
							$scope.raccNumberFreeze = true;
						} else {
							$scope.raccNumberFreeze = false;
						}
						if (response.BankDetailsList[0].BankId) {
							$rootScope.formData.fields.bankID = response.BankDetailsList[0].BankId.toString();
							setTimeout(function () {
								$(".select").select2();
							}, 100);
						}
						if ($rootScope.formData.threeinone && $scope.formData.fields.bankID) {
							$('#pBank').addClass('freeze');
						}
						//$('#pBank').val($scope.formData.fields.bankID);

						//$scope.changeChar();
						$('#ifsc_value').val(response.BankDetailsList[0].IFSC);
						/****for IE fix ***/
						$('#ifsc_value').focus();
						if ($rootScope.formData.threeinone && response.BankDetailsList[0].IFSC) {
							$('#ifsc_value').prop('disabled', true);
						} else {
							$('#ifsc_value').prop('disabled', false);
						}
					} else {
						Bank_Info_Stage = "Bank_Info_Stage" + "-" + localStorage.getItem("RxReferenceNumber");
						if (JSON.parse(localStorage.getItem(Bank_Info_Stage)) != null) {
							var Bank_Info = JSON.parse(localStorage.getItem(Bank_Info_Stage));

							$scope.disableIFSC = false;
							$rootScope.formData.fields.accNumber = Bank_Info.accountnumber;
							$rootScope.formData.fields.accountNumber = $rootScope.formData.fields.accNumber;
							$rootScope.formData.fields.raccNumber = Bank_Info.raccountnumber;
							$rootScope.formData.fields.bankID = Bank_Info.bankID;
							setTimeout(function () {
								$('#ifsc_value').val(Bank_Info.ifsc);
								$(".select").select2();
							}, 500);
							//$rootScope.axisSignatureAction = true;
							//$scope.axisSignature = true;
							//$scope.changeChar();
						}
					}
				
			}).error(function () {
				$rootScope.formData.apiLoading = false;
			});
		} else {
			Bank_Info_Stage = "Bank_Info_Stage" + "-" + localStorage.getItem("RxReferenceNumber");
			if (JSON.parse(localStorage.getItem(Bank_Info_Stage)) != null) {
				var Bank_Info = JSON.parse(localStorage.getItem(Bank_Info_Stage));
				$('#ifsc_value').val(Bank_Info.ifsc);
				/****for IE fix ***/
				$('#ifsc_value').focus();
				$scope.disableIFSC = false;
				$rootScope.formData.fields.accNumber = Bank_Info.accountnumber;
				$rootScope.formData.fields.accountNumber = $rootScope.formData.fields.accNumber;
				$rootScope.formData.fields.raccNumber = Bank_Info.raccountnumber;
				$rootScope.formData.fields.bankID = Bank_Info.bankID;
				setTimeout(function () {
					$('#ifsc_value').val(Bank_Info.ifsc);

					$(".select").select2();
				}, 500);
				//$scope.changeChar();
			}
		}
		
	}
	if ($rootScope.formData.tokenValidation && !$rootScope.EncryptToken) {
		var url = "GetEncrptToken";
		var sendData = {
			ReferenceNumber: localStorage.getItem('AxNo')
		}
		$rootScope.formData.apiLoading = true;
		serverService.apiCall(url, sendData).success(function (response) {
			$rootScope.formData.apiLoading = false;
			if (response.EncryptToken) {
				$rootScope.EncryptToken = response.EncryptToken;
				$scope.getBankInfo();
			} else {
				$rootScope.clearBrowsingData();
				$('#APIResponse').modal({
					backdrop: 'static',
					keyboard: false
				});
				$rootScope.apiResponseErrorMsg = response.ErrorMessage;
			}
		});

	} else {
		$scope.getBankInfo();
	}

	$scope.bankDataSubmit = function () {
		/*var axisSign=""
		var axisSignature = $('#axisSignature').prop('checked');
		if(axisSignature === true){
			axisSign="1";
		}else if(axisSignature === false){
			axisSign="0";
		}*/
		$('#pennyModal').modal('hide');
		$(document.body).removeClass('modal-open');
		$('.modal-backdrop').remove();
		var s_url = "DIYClientBankRegistration";
		var sendData = {
			ObjCDIYBank: {
				ReferenceNumber: $rootScope.formData.ReferenceNumber,
				BankDetailsId: 1,
				BankName: $rootScope.formData.fields.bankName,
				BankId: $rootScope.formData.fields.bankID,
				Address: $rootScope.formData.Branch,
				IFSC: $rootScope.formData.fields.ifscCode,
				MICRCode: $rootScope.formData.fields.micrCode,
				AccountNumber: $rootScope.formData.fields.raccNumber,
				AccountTypeId: 1,
				BrowserType: $rootScope.formData.browserType,
				EncryptToken: $rootScope.EncryptToken,
				//AxisSignature: axisSign
				AxisSignature: "1"
			},
			IsDiy: true
		}
		$rootScope.formData.apiLoading = true;
		var tokenParams = {
			'Email': ($rootScope.formData.fields.email !== null && $rootScope.formData.fields.email !== '') ? $rootScope.formData.fields.email : localStorage.getItem('RxEmail'),
			'Mobile': ($rootScope.formData.fields.mobile !== null && $rootScope.formData.fields.mobile !== '') ? $rootScope.formData.fields.mobile : localStorage.getItem('RxMobile'),
			'PanNumber': ($rootScope.formData.fields.panNumber !== null && $rootScope.formData.fields.panNumber !== '') ? $rootScope.formData.fields.panNumber : localStorage.getItem('RxPan'),
			'DOB': ($rootScope.formData.dob !== null && !angular.isUndefined($rootScope.formData.dob) && $rootScope.formData.fields.dob !== '') ? $rootScope.formData.dob : localStorage.getItem('DOB'),
		}
		//serverService.apiTokenCall(s_url, sendData, tokenParams).success(function (response)
		serverService.apiCall(s_url, sendData).success(function (response) {
			$rootScope.formData.apiLoading = false;
				if(response.EncryptToken){
					$rootScope.EncryptToken = response.EncryptToken;
					localStorage.setItem('AxToken', response.EncryptToken);
				}
				else{
					if($rootScope.formData.tokenValidation){
						$rootScope.clearBrowsingData();
						$('#APIResponse').modal({backdrop: 'static',keyboard: false});
						$rootScope.apiResponseErrorMsg = "Session Timed Out";
					}
				}

				if (response.IsSuccess) {
					var Bank_Info = new Object();
					Bank_Info.ifsc = $('#ifsc_value').val();
					Bank_Info.accountnumber = $rootScope.formData.fields.accountNumber;
					Bank_Info.raccountnumber = $rootScope.formData.fields.raccNumber;
					Bank_Info.bankID = $rootScope.formData.fields.bankID;
					var Bank_Info_Post = JSON.stringify(Bank_Info);
					Bank_Info_Stage = "Bank_Info_Stage" + "-" + localStorage.getItem("RxReferenceNumber");
					localStorage.setItem(Bank_Info_Stage, Bank_Info_Post);
					$rootScope.fourthCompleted = true;
					dataLayer.push({
						event: 'StageChange',
						attributes: {
							'level complete': '5',
							'IFSC': $rootScope.formData.fields.ifscCode,
							'AccountNumber': $rootScope.formData.fields.raccNumber
						}
					});
					$rootScope.getAPI = false;
					$rootScope.formData.noData = false;
					$rootScope.formData.ifscOption = false;

					$state.go('products', {
						mobile: $rootScope.formData.EncMobile
					});

				} else {
					$('#connection').modal('show');
				}
			
		}).error(function () {
			$('#connection').modal('show');
		});
	}

	$scope.pennyValidation = function () {
		var s_url = 'RazorpayAccountValidation';
		var sendData = {
			"ReferenceNumber": $rootScope.formData.ReferenceNumber,
			"AccountNumber": $rootScope.formData.fields.raccNumber,
			"IFSCCode": $rootScope.formData.fields.ifscCode
		};
		$rootScope.formData.apiLoading = true;
		serverService.apiCall(s_url, sendData).success(function (response) {
			$rootScope.formData.apiLoading = false;
			if (response.IsSuccess) {
				if(response.IsNameMatched === true || response.IsNameMatched === 'true'){					
					$scope.bankDataSubmit();
				}else{
					if(response.CustomerName){
						$scope.pennyResponse = "Your name obtained from bank  '"+response.CustomerName+"', doesn't matches with name obtained from PAN site";
					}
					else{
						$scope.pennyResponse = "Your name obtained from bank doesn't matches with name obtained from PAN site";
					}
					$('#pennyModal').modal({
					backdrop: 'static',
					keyboard: false
				});
				}
			} else {
				//$scope.pennyResponse = "Your name obtained from bank doesn't matches with name obtained from PAN site";
				$scope.pennyResponse = "Please ensure your entered Bank Account number is correct.";
				$('#pennyModal').modal({
					backdrop: 'static',
					keyboard: false
				});
			}
		}).error(function(){			
			$rootScope.formData.apiLoading = false;
			$scope.pennyResponse = "Your name obtained from bank doesn't matches with name obtained from PAN site";
			$('#pennyModal').modal({
					backdrop: 'static',
					keyboard: false
				});
		})
	}
	
	$scope.notAxisClient = function () {
		var nonAxis = "NonAxisClientMappingAxisBank?ReferenceNumber=" + localStorage.getItem('RxReferenceNumber');
			$('#myModal').modal('hide');
			serverService.getList(nonAxis).then(function (response) {
		});
	}
	$scope.bankValidate = function () {
		$rootScope.formData.fields.accountNumber = $rootScope.formData.fields.accNumber;
		var error = 0;
		$rootScope.formData.fields.ifscCode = $('#ifsc_value').val();
		if ($rootScope.formData.fields.bankID == null || $rootScope.formData.fields.bankID == '') {
			$scope.bankNameError = true;
			error++;
		}
		if ($rootScope.formData.fields.ifscCode == null || $rootScope.formData.fields.ifscCode == '' || $rootScope.formData.fields.ifscCode.length != 11 || $rootScope.formData.ifscError) {
			$scope.ifscError = true;
			error++;
		}
		if ($rootScope.formData.fields.accountNumber == null || $rootScope.formData.fields.accountNumber == '' || ($rootScope.formData.fields.accountNumber).length < 6) {
			$scope.accInvalid = true;
			error++;
		} else if ($rootScope.formData.fields.accountNumber != $rootScope.formData.fields.raccNumber) {
			$scope.accountMismatch = true;
			error++;
		} else {
			$scope.accountMismatch = false;
		}
		if (error == 0) {
			$scope.pennyValidation();
			//$scope.bankDataSubmit();
			/*if ((localStorage.getItem('IsKRA') == 'true' || $rootScope.formData.kara) && $rootScope.formData.isg) {
				$scope.pennyValidation();
			} else {
				$scope.bankDataSubmit();
			}*/
		}
	}

	window.onbeforeunload = function () {
		var Bank_Info = new Object();
		Bank_Info.ifsc = $('#ifsc_value').val();
		Bank_Info.accountnumber = $rootScope.formData.fields.accNumber;
		Bank_Info.raccountnumber = $rootScope.formData.fields.raccNumber;
		Bank_Info.bankID = $rootScope.formData.fields.bankID;
		var Bank_Info_Post = JSON.stringify(Bank_Info);
		Bank_Info_Stage = "Bank_Info_Stage" + "-" + localStorage.getItem("RxReferenceNumber");
		localStorage.setItem(Bank_Info_Stage, Bank_Info_Post);
	}

	$scope.bankBtn = function () {
		$('button.btn-primary').focus();
	}

	$rootScope.$on("getAPI", function (evt, data) {
		if ($rootScope.formData.threeinone) {
			$rootScope.getAPI = false;
			$scope.getBankInfo();
		}
	});
});
